"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// plugins/minecraft-body/src/index.ts
var index_exports = {};
__export(index_exports, {
  createPlugin: () => createPlugin,
  default: () => index_default
});
module.exports = __toCommonJS(index_exports);
var import_node_path3 = __toESM(require("node:path"));

// plugins/minecraft-body/src/manager.ts
var import_node_child_process = require("node:child_process");
var import_node_crypto = require("node:crypto");
var import_promises = require("node:fs/promises");
var import_node_path = __toESM(require("node:path"));
function validateConnection(value) {
  if (!value || typeof value !== "object") throw new Error("\u8FDE\u63A5\u8BBE\u7F6E\u65E0\u6548");
  const config = value;
  const name = (key, max) => {
    const value2 = config[key];
    if (typeof value2 !== "string" || !value2.trim() || value2.length > max || /[\s\x00-\x1f]/.test(value2)) throw new Error(`${key} \u65E0\u6548`);
    return value2;
  };
  if (!Number.isInteger(config.port) || Number(config.port) < 1 || Number(config.port) > 65535) throw new Error("\u7AEF\u53E3\u5E94\u4E3A 1..65535");
  if (config.auth !== "offline" && config.auth !== "microsoft") throw new Error("\u767B\u5F55\u65B9\u5F0F\u65E0\u6548");
  if (typeof config.version !== "string" || !/^(?:|1\.\d+(?:\.\d+)?)$/.test(config.version)) throw new Error("\u7248\u672C\u5E94\u4E3A\u7A7A\uFF08\u81EA\u52A8\uFF09\u6216 Java \u7248\u7248\u672C\u53F7");
  const username = name("username", config.auth === "offline" ? 16 : 254);
  const owner = name("owner", 16);
  if (!/^[a-zA-Z0-9_]{1,16}$/.test(owner) || config.auth === "offline" && !/^[a-zA-Z0-9_]{1,16}$/.test(username)) throw new Error("\u73A9\u5BB6\u540D\u53EA\u80FD\u542B\u5B57\u6BCD\u3001\u6570\u5B57\u548C\u4E0B\u5212\u7EBF");
  if (config.autoSurvival !== void 0 && typeof config.autoSurvival !== "boolean") throw new Error("\u81EA\u52A8\u751F\u5B58\u9009\u9879\u65E0\u6548");
  return { host: name("host", 253), port: Number(config.port), username, owner, auth: config.auth, version: config.version, autoSurvival: config.autoSurvival === true };
}
var BodyManager = class {
  constructor(runtime, dataRoot, spawn = import_node_child_process.fork) {
    this.runtime = runtime;
    this.dataRoot = dataRoot;
    this.spawn = spawn;
  }
  taskOwner;
  // Invalidates observations sent before a newer action or connection transition.
  actionRevision = 0;
  knownActionId;
  observationSequence = 0;
  appliedObservation = 0;
  rpcPending = /* @__PURE__ */ new Map();
  child;
  starting = false;
  stopping;
  closed = false;
  state = { connected: false };
  login;
  results = [];
  notices = [];
  pending = /* @__PURE__ */ new Map();
  status() {
    return {
      running: !!this.child,
      starting: this.starting,
      state: this.state,
      login: this.login,
      results: [...this.results],
      notices: [...this.notices]
    };
  }
  notice(data) {
    this.notices.push({ time: (/* @__PURE__ */ new Date()).toISOString(), data });
    if (this.notices.length > 30) this.notices.shift();
  }
  message(child, message) {
    if (this.child !== child || this.closed || !message || typeof message.type !== "string") return;
    if (message.type === "task-reply" && message.id) {
      const pending = this.rpcPending.get(message.id);
      if (!pending) return;
      clearTimeout(pending.timer);
      this.rpcPending.delete(message.id);
      if (message.data?.error) pending.reject(new Error(message.data.error));
      else {
        const snapshot = message.data?.value;
        if (pending.observation) {
          const { revision, sequence } = pending.observation;
          if (revision !== this.actionRevision || sequence < this.appliedObservation) {
            pending.reject(new Error("\u8EAB\u4F53\u89C2\u6D4B\u5DF2\u8FC7\u671F\uFF1B\u4E0D\u80FD\u8986\u76D6\u8F83\u65B0\u7684\u52A8\u4F5C\u72B6\u6001"));
            return;
          }
          if (!snapshot || typeof snapshot.connected !== "boolean") {
            pending.reject(new Error("\u8EAB\u4F53\u89C2\u6D4B\u65E0\u6548"));
            return;
          }
          if (snapshot.activeAction?.id && snapshot.activeAction.id !== this.knownActionId) {
            this.actionRevision++;
            this.knownActionId = snapshot.activeAction.id;
          }
          this.state = snapshot;
          this.appliedObservation = sequence;
        }
        pending.resolve(snapshot);
      }
      return;
    }
    if (message.type === "state") {
      const activeId = message.data?.activeAction?.id;
      if (activeId && activeId !== this.knownActionId) {
        this.actionRevision++;
        this.knownActionId = activeId;
      }
      if (message.data?.connected !== this.state.connected) this.actionRevision++;
      this.state = message.data;
      if (this.state.connected) this.login = void 0;
    } else if (message.type === "login") this.login = message.data;
    else if (message.type === "result" || message.type === "rejected") {
      const result = message.type === "result" ? message.data : { id: message.id, status: "rejected", reason: message.data };
      if (typeof result?.id !== "string") {
        this.notice(message.data);
        return;
      }
      if (result.status !== "active") {
        clearTimeout(this.pending.get(result.id));
        this.pending.delete(result.id);
      }
      const previous = this.results.findIndex((entry) => entry.id === result.id);
      if (previous >= 0) this.results[previous] = result;
      else this.results.push(result);
      if (this.results.length > 50) this.results.shift();
    } else if (message.type === "ended") {
      this.actionRevision++;
      this.state = { ...this.state, connected: false };
      this.notice(message.data);
    } else this.notice(message.data);
  }
  lost(child, reason) {
    if (this.child !== child) return;
    this.actionRevision++;
    this.knownActionId = void 0;
    this.child = void 0;
    this.taskOwner = void 0;
    for (const pending of this.rpcPending.values()) {
      clearTimeout(pending.timer);
      pending.reject(new Error(reason));
    }
    this.rpcPending.clear();
    this.login = void 0;
    this.state = { ...this.state, connected: false, activeAction: null };
    for (const timer of this.pending.values()) clearTimeout(timer);
    this.pending.clear();
    this.results = this.results.map((result) => ["submitted", "active"].includes(result.status) ? { ...result, status: "disconnected", reason, effectsUncertain: ["collect", "craft", "give", "pickup", "eat", "equip", "equip_armor", "equip_shield", "place", "deposit", "withdraw", "sleep", "wake", "door", "till", "plant", "harvest", "smelt", "defend", "escape"].includes(result.action) } : result);
    this.notice(reason);
  }
  failed(child, reason) {
    if (this.child !== child) return;
    this.actionRevision++;
    this.state = { ...this.state, connected: false };
    this.notice(reason);
    if (!child.pid) this.lost(child, reason);
    child.kill();
  }
  async start(value) {
    if (this.closed) throw new Error("\u63D2\u4EF6\u5DF2\u505C\u6B62");
    if (this.child || this.starting) throw new Error("\u8EAB\u4F53\u5DF2\u7ECF\u8FD0\u884C\u6216\u6B63\u5728\u542F\u52A8");
    const config = validateConnection(value);
    this.starting = true;
    try {
      await (0, import_promises.mkdir)(this.dataRoot, { recursive: true });
      const root = await (0, import_promises.realpath)(this.dataRoot);
      const profiles = import_node_path.default.join(root, "microsoft-auth");
      await (0, import_promises.mkdir)(profiles, { recursive: true });
      if (import_node_path.default.dirname(await (0, import_promises.realpath)(profiles)) !== root) throw new Error("\u767B\u5F55\u7F13\u5B58\u76EE\u5F55\u4E0D\u80FD\u94FE\u63A5\u5230\u63D2\u4EF6\u6570\u636E\u76EE\u5F55\u5916");
      if (this.closed) throw new Error("\u63D2\u4EF6\u5DF2\u505C\u6B62");
      this.results = [];
      this.login = void 0;
      this.state = { connected: false };
      const options = {
        execArgv: [],
        cwd: this.runtime,
        stdio: ["ignore", "ignore", "ignore", "ipc"],
        env: { ...process.env, ELECTRON_RUN_AS_NODE: "1", NODE_PATH: "" },
        windowsHide: true
      };
      const child = this.spawn(import_node_path.default.join(this.runtime, "sidecar.cjs"), [], options);
      this.child = child;
      child.on("message", (message) => this.message(child, message));
      child.once("exit", () => this.lost(child, "\u8EAB\u4F53\u8FDB\u7A0B\u5DF2\u9000\u51FA\uFF0C\u52A8\u4F5C\u4E0D\u4F1A\u91CD\u653E"));
      child.once("error", (error) => this.failed(child, error.message));
      child.send({ type: "start", config, profilesFolder: profiles }, (error) => {
        if (error) this.failed(child, error.message);
      });
      return this.status();
    } finally {
      this.starting = false;
    }
  }
  action(value) {
    if (this.taskOwner) throw new Error("\u9AD8\u5C42\u4EFB\u52A1\u5360\u7528\u8EAB\u4F53\uFF1B\u8BF7\u5148\u53D6\u6D88\u4EFB\u52A1");
    return this.submitAction(value);
  }
  submitAction(value, taskId, allowedRegion) {
    if (this.closed || !this.child?.connected || !this.state.connected) throw new Error("\u7B49\u5F85\u673A\u5668\u4EBA\u51FA\u751F\u540E\u518D\u6267\u884C\u52A8\u4F5C");
    const input = value;
    const id = (0, import_node_crypto.randomUUID)();
    const request = { id, action: input?.action, material: input?.material, count: input?.count, timeoutMs: input?.timeoutMs, position: input?.position, open: input?.open, taskId, allowedRegion };
    const { validateAction } = require(import_node_path.default.join(this.runtime, "body.cjs"));
    validateAction(request);
    if (this.state.activeAction || this.pending.size) throw new Error("\u5DF2\u6709\u52A8\u4F5C\u8FD0\u884C\uFF0C\u8BF7\u5148\u505C\u6B62");
    const child = this.child;
    this.actionRevision++;
    this.knownActionId = id;
    const result = { id, action: request.action, status: "submitted" };
    this.results.push(result);
    if (this.results.length > 50) this.results.shift();
    this.pending.set(id, setTimeout(() => {
      this.notice("\u8EAB\u4F53\u672A\u5728\u622A\u6B62\u65F6\u95F4\u8FD4\u56DE\u7ED3\u679C\uFF1B\u5173\u95ED\u8EAB\u4F53\uFF0C\u4E0D\u81EA\u52A8\u91CD\u8BD5");
      void this.stop().catch((error) => this.notice(error.message));
    }, Number(request.timeoutMs ?? 6e4) + 5e3));
    child.send({ type: "action", request }, (error) => {
      if (error) this.failed(child, error.message);
    });
    return result;
  }
  rpc(op, taskId, region) {
    if (this.closed || !this.child?.connected || !this.state.connected) return Promise.reject(new Error("\u8EAB\u4F53\u672A\u8FDE\u63A5"));
    const id = (0, import_node_crypto.randomUUID)(), child = this.child;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.rpcPending.delete(id);
        reject(new Error("\u8EAB\u4F53\u4EFB\u52A1\u67E5\u8BE2\u8D85\u65F6\uFF1B\u4E0D\u91CD\u8BD5"));
      }, 5e3);
      this.rpcPending.set(id, { resolve, reject, timer, ...op === "observe" ? { observation: { revision: this.actionRevision, sequence: ++this.observationSequence } } : {} });
      child.send({ type: "task-control", id, op, taskId, region }, (error) => {
        if (error) {
          clearTimeout(timer);
          this.rpcPending.delete(id);
          reject(error);
        }
      });
    });
  }
  async assertQuiescent(region) {
    if (!this.child) return;
    if (!this.state.connected) throw new Error("\u5148\u65AD\u5F00\u5C1A\u672A\u5C31\u7EEA\u7684\u8EAB\u4F53\u8FDB\u7A0B");
    const snapshot = await this.rpc("observe", "acknowledge", region);
    if (snapshot.activeAction || this.pending.size) throw new Error("\u5E95\u5C42\u52A8\u4F5C\u4ECD\u5728\u8FD0\u884C\u6216 draining");
  }
  async acquireTask(taskId, region) {
    if (this.taskOwner || this.pending.size || this.state.activeAction) throw new Error("\u8EAB\u4F53\u5DF2\u6709\u4EFB\u52A1\u6216\u52A8\u4F5C");
    this.taskOwner = taskId;
    try {
      await this.rpc("acquire", taskId, region);
    } catch (error) {
      await this.stop();
      this.taskOwner = void 0;
      throw error;
    }
  }
  async releaseTask(taskId) {
    if (this.taskOwner !== taskId) return;
    if (this.child?.connected && this.state.connected) await this.rpc("release", taskId);
    this.taskOwner = void 0;
  }
  async observeTask(taskId, region) {
    if (this.taskOwner !== taskId) throw new Error("\u4EFB\u52A1\u4E0D\u62E5\u6709\u8EAB\u4F53");
    return this.rpc("observe", taskId, region);
  }
  async taskAction(taskId, action, region) {
    if (this.taskOwner !== taskId) throw new Error("\u4EFB\u52A1\u4E0D\u62E5\u6709\u8EAB\u4F53");
    const submitted = this.submitAction(action, taskId, region);
    const until = Date.now() + (action.timeoutMs ?? 3e4) + 8e3;
    for (; ; ) {
      const result = this.results.find((r) => r.id === submitted.id);
      if (result && !["submitted", "active"].includes(result.status)) {
        if (result.effectsUncertain || !this.state.connected) return result;
        const fresh = await this.observeTask(taskId, region);
        if (!fresh.activeAction) return { ...result, after: fresh };
      }
      if (Date.now() > until) {
        this.cancel();
        return { id: submitted.id, action: action.action, status: "timed_out", effectsUncertain: true, reason: "\u672A\u786E\u8BA4\u5E95\u5C42\u8C03\u7528\u7ED3\u675F" };
      }
      await new Promise((resolve) => setTimeout(resolve, 25));
    }
  }
  cancel() {
    if (!this.closed && this.child?.connected) this.child.send({ type: "cancel" }, (error) => {
      if (error) this.notice(error.message);
    });
    return { requested: true };
  }
  async stop() {
    if (this.stopping) return this.stopping;
    const child = this.child;
    if (!child) return;
    this.stopping = new Promise((resolve, reject) => {
      let failureTimer;
      const force = () => {
        failureTimer ??= setTimeout(() => {
          this.state = { ...this.state, connected: false };
          reject(new Error("\u8EAB\u4F53\u8FDB\u7A0B\u5C1A\u672A\u786E\u8BA4\u9000\u51FA\uFF1B\u4FDD\u7559\u53E5\u67C4\uFF0C\u7981\u6B62\u518D\u6B21\u8FDE\u63A5"));
        }, 2e3);
        child.kill();
      };
      const timer = setTimeout(force, 2e3);
      child.once("exit", () => {
        clearTimeout(timer);
        clearTimeout(failureTimer);
        resolve();
      });
      if (child.connected) child.send({ type: "stop" }, (error) => {
        if (error) force();
      });
      else force();
    });
    try {
      await this.stopping;
      this.lost(child, "\u8EAB\u4F53\u5DF2\u65AD\u5F00\uFF0C\u52A8\u4F5C\u4E0D\u4F1A\u91CD\u653E");
    } finally {
      this.stopping = void 0;
    }
  }
  async close() {
    this.closed = true;
    await this.stop();
  }
};

// plugins/minecraft-body/src/controller.ts
var import_node_crypto2 = require("node:crypto");
var import_node_fs = require("node:fs");
var import_node_path2 = __toESM(require("node:path"));

// plugins/minecraft-body/src/planner.ts
var ITEMS = /* @__PURE__ */ new Set(["oak_log", "oak_planks", "stick", "crafting_table", "wooden_pickaxe"]);
var validCount = (n) => Number.isSafeInteger(n) && n > 0;
var pointKey = (p) => `${p.x},${p.y},${p.z}`;
var comparePoints = (a, b) => a.x - b.x || a.y - b.y || a.z - b.z;
function createRecipePlan(snapshot, goal) {
  const inventory = { ...snapshot.inventory };
  const steps = [];
  const desiredTotal = goal.desiredTotal;
  const requiredDelta = Math.max(0, desiredTotal - (inventory[goal.item] || 0));
  const finish = (decision) => ({ decision, desiredTotal, requiredDelta, steps, remainingInventory: inventory });
  function fail(reason) {
    throw new Error(reason);
  }
  try {
    if (goal.item !== "wooden_pickaxe" || !validCount(desiredTotal)) fail("unsupported_goal");
    if (Object.values(inventory).some((n) => !Number.isSafeInteger(n) || n < 0)) fail("invalid_inventory");
    if (!snapshot.connected) fail("not_connected");
    const region = goal.allowedRegion;
    const finitePoint = (p) => !!p && [p.x, p.y, p.z].every(Number.isFinite);
    if (!region || !finitePoint(region.min) || !finitePoint(region.max) || ["x", "y", "z"].some((axis) => region.min[axis] > region.max[axis])) fail("invalid_allowed_region");
    const inside = (p) => finitePoint(p) && p.x >= region.min.x && p.x <= region.max.x && p.y >= region.min.y && p.y <= region.max.y && p.z >= region.min.z && p.z <= region.max.z;
    if (snapshot.dimension !== region.dimension || !inside(snapshot.position)) fail("outside_allowed_region");
    if (requiredDelta === 0) return finish({ kind: "completed", reason: "observed_inventory_goal_met" });
    if (!validCount(goal.actionBudget)) fail("plan_budget_exhausted");
    const budget = Math.min(goal.actionBudget, 64);
    const catalog = snapshot.recipeCatalog;
    if (!catalog?.supported || !catalog.version || catalog.version !== snapshot.protocolVersion || catalog.source !== "minecraft-data") fail("unsupported_recipe_version");
    if (!Array.isArray(catalog.recipes)) fail("unsupported_recipe_catalog");
    const observations = snapshot.taskObservation;
    if (!observations) fail("missing_task_observation");
    const reachable = (value) => value?.reachable !== false && value?.safe !== false;
    const tables = observations.craftingTables.filter((p) => inside(p) && reachable(p)).sort(comparePoints);
    let table = tables[0];
    const placements = observations.placementCandidates.filter((p) => inside(p) && reachable(p) && [p.x, p.y, p.z].every(Number.isInteger)).sort(comparePoints);
    const logs = observations.logs.filter((r) => r.name === "oak_log" && inside(r.position) && reachable(r)).sort((a, b) => comparePoints(a.position, b.position));
    const usedLogs = /* @__PURE__ */ new Set();
    const usedDrops = /* @__PURE__ */ new Set();
    const drops = observations.drops.filter((r) => ITEMS.has(r.name) && inside(r.position) && reachable(r) && (r.count === void 0 || validCount(r.count))).sort((a, b) => comparePoints(a.position, b.position));
    const push = (action, recipe, batches) => {
      if (steps.length >= budget) fail("plan_budget_exhausted");
      steps.push({ action, ...recipe ? { recipeId: recipe.id, recipeBatches: batches } : {} });
    };
    const stack = /* @__PURE__ */ new Set();
    const ensure = (name, desired) => {
      let delta = desired - (inventory[name] || 0);
      if (delta <= 0) return;
      for (const drop of drops.filter((r) => r.name === name)) {
        const key = `${name}:${pointKey(drop.position)}`;
        if (usedDrops.has(key)) continue;
        push({ action: "pickup", material: name, count: 1, position: { ...drop.position } });
        usedDrops.add(key);
        inventory[name] = (inventory[name] || 0) + (drop.count ?? 1);
        delta = desired - inventory[name];
        if (delta <= 0) return;
      }
      if (!ITEMS.has(name)) fail(`unsupported_ingredient:${name}`);
      if (name === "oak_log") {
        if (!goal.allowCollect) fail("collection_not_authorized:oak_log");
        for (let i = 0; i < delta; i++) {
          const log = logs.find((r) => !usedLogs.has(pointKey(r.position)));
          if (!log) fail("missing_safe_reachable_resource:oak_log");
          usedLogs.add(pointKey(log.position));
          push({ action: "collect", material: "\u6728\u5934", count: 1, position: { ...log.position } });
          inventory.oak_log = (inventory.oak_log || 0) + 1;
        }
        return;
      }
      if (stack.has(name)) fail(`cyclic_recipe:${name}`);
      const recipes = catalog.recipes.filter((r) => r.output?.name === name).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
      const recipe = recipes.find((r) => Array.isArray(r.ingredients) && r.ingredients.length > 0 && r.ingredients.every((i) => ITEMS.has(i.name)));
      if (!recipe || !validCount(recipe.output.count) || !recipe.ingredients.every((i) => validCount(i.count))) fail(`unsupported_recipe:${name}`);
      stack.add(name);
      if (recipe.requiresTable && !table) {
        if (!goal.allowPlace) fail("missing_workbench:placement_not_authorized");
        const target = placements[0];
        if (!target) fail("missing_workbench:no_safe_placement");
        try {
          ensure("crafting_table", 1);
        } catch (error) {
          fail(`missing_workbench:needs_materials:${error.message}`);
        }
        inventory.crafting_table -= 1;
        push({ action: "place", material: "crafting_table", count: 1, position: { ...target } });
        table = target;
      }
      const batches = Math.ceil(delta / recipe.output.count);
      const inputs = /* @__PURE__ */ new Map();
      for (const input of recipe.ingredients) inputs.set(input.name, (inputs.get(input.name) || 0) + input.count * batches);
      for (const [input, count] of inputs) {
        ensure(input, count);
        inventory[input] -= count;
      }
      push({ action: "craft", material: name, count: delta, ...recipe.requiresTable ? { position: { ...table } } : {} }, recipe, batches);
      inventory[name] = (inventory[name] || 0) + recipe.output.count * batches;
      stack.delete(name);
    };
    ensure(goal.item, desiredTotal);
    if (!steps.length || (inventory[goal.item] || 0) < desiredTotal) fail("incomplete_plan");
    return finish({ kind: "action", action: steps[0].action, reason: "bounded_recipe_plan_reobserve_after_action" });
  } catch (error) {
    return finish({ kind: "blocked", reason: error.message });
  }
}
function planNext(snapshot, goal) {
  return createRecipePlan(snapshot, goal).decision;
}

// plugins/minecraft-body/src/controller.ts
function validateGoal(value) {
  if (!value || typeof value !== "object") throw new Error("\u7ED3\u6784\u5316\u76EE\u6807\u65E0\u6548");
  const v = value;
  const keys = ["item", "desiredTotal", "equip", "allowedRegion", "allowCollect", "allowPlace", "timeoutMs", "actionBudget"];
  if (Object.keys(v).some((k) => !keys.includes(k)) || v.item !== "wooden_pickaxe" || v.desiredTotal !== void 0 && v.desiredTotal !== 1) throw new Error("V1 \u4EC5\u652F\u6301 wooden_pickaxe \u603B\u91CF 1");
  const r = v.allowedRegion;
  if (!r || typeof r.dimension !== "string" || !["overworld", "minecraft:overworld"].includes(r.dimension)) throw new Error("\u5FC5\u987B\u6307\u5B9A\u4E3B\u4E16\u754C\u5141\u8BB8\u533A\u57DF");
  for (const axis of ["x", "y", "z"]) {
    if (!Number.isFinite(r.min?.[axis]) || !Number.isFinite(r.max?.[axis]) || r.max[axis] < r.min[axis] || r.max[axis] - r.min[axis] > 48 || Math.abs(r.min[axis]) > 3e7 || Math.abs(r.max[axis]) > 3e7) throw new Error("\u5141\u8BB8\u533A\u57DF\u6BCF\u8FB9\u987B\u5728 0..48 \u683C\u5185");
  }
  for (const key of ["equip", "allowCollect", "allowPlace"]) if (v[key] !== void 0 && typeof v[key] !== "boolean") throw new Error(`${key} \u987B\u4E3A\u5E03\u5C14\u503C`);
  const timeoutMs = v.timeoutMs ?? 12e4, actionBudget = v.actionBudget ?? 16;
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1e3 || timeoutMs > 3e5 || !Number.isInteger(actionBudget) || actionBudget < 1 || actionBudget > 32) throw new Error("\u65F6\u95F4\u9884\u7B97 1000..300000 \u6BEB\u79D2\uFF1B\u52A8\u4F5C\u9884\u7B97 1..32");
  return { item: "wooden_pickaxe", desiredTotal: 1, equip: v.equip !== false, allowedRegion: { dimension: "overworld", min: { x: r.min.x, y: r.min.y, z: r.min.z }, max: { x: r.max.x, y: r.max.y, z: r.max.z } }, allowCollect: v.allowCollect === true, allowPlace: v.allowPlace === true, timeoutMs, actionBudget };
}
function sanitizeSnapshot(s) {
  const { connected, position, dimension, inventory, heldItem, health, activeAction, sampledAt, taskObservation, protocolVersion } = s;
  return { connected, position, dimension, inventory, heldItem, health, activeAction, sampledAt, taskObservation, protocolVersion };
}
var Journal = class {
  root;
  constructor(root) {
    (0, import_node_fs.mkdirSync)(root, { recursive: true });
    const base = (0, import_node_fs.realpathSync)(root);
    this.root = import_node_path2.default.join(base, "tasks-v1");
    (0, import_node_fs.mkdirSync)(this.root, { recursive: true });
    if ((0, import_node_fs.realpathSync)(this.root) !== this.root) throw new Error("\u4EFB\u52A1\u76EE\u5F55\u4E0D\u80FD\u662F\u7B26\u53F7\u94FE\u63A5");
  }
  file(name) {
    const file = import_node_path2.default.join(this.root, name);
    if ((0, import_node_fs.existsSync)(file) && (0, import_node_fs.lstatSync)(file).isSymbolicLink()) throw new Error("\u4EFB\u52A1\u6587\u4EF6\u4E0D\u80FD\u662F\u7B26\u53F7\u94FE\u63A5");
    return file;
  }
  load() {
    const f = this.file("state.json");
    if (!(0, import_node_fs.existsSync)(f)) return;
    if ((0, import_node_fs.statSync)(f).size > 1024 * 1024) throw new Error("\u4EFB\u52A1\u72B6\u6001\u6587\u4EF6\u8FC7\u5927");
    return JSON.parse((0, import_node_fs.readFileSync)(f, "utf8"));
  }
  write(task) {
    const temp = this.file("state.tmp");
    (0, import_node_fs.writeFileSync)(temp, JSON.stringify(task), { mode: 384 });
    (0, import_node_fs.renameSync)(temp, this.file("state.json"));
  }
  append(event) {
    const file = this.file("events.jsonl");
    if ((0, import_node_fs.existsSync)(file) && (0, import_node_fs.statSync)(file).size > 4 * 1024 * 1024) {
      (0, import_node_fs.rmSync)(this.file("events.2.jsonl"), { force: true });
      if ((0, import_node_fs.existsSync)(this.file("events.1.jsonl"))) (0, import_node_fs.renameSync)(this.file("events.1.jsonl"), this.file("events.2.jsonl"));
      (0, import_node_fs.renameSync)(file, this.file("events.1.jsonl"));
    }
    (0, import_node_fs.appendFileSync)(file, JSON.stringify({ time: (/* @__PURE__ */ new Date()).toISOString(), ...event }) + "\n", { mode: 384 });
  }
};
var TaskController = class {
  constructor(body, dataRoot) {
    this.body = body;
    this.dataRoot = dataRoot;
  }
  task;
  journal;
  starting = false;
  closed = false;
  loop;
  cancelRequested = false;
  init() {
    if (this.journal) return;
    this.journal = new Journal(this.dataRoot);
    this.task = this.journal.load();
    if (this.task?.state === "running") {
      this.task.state = "interrupted";
      this.task.reason = "\u63D2\u4EF6\u91CD\u542F\uFF1B\u4E0D\u6062\u590D\u6216\u91CD\u653E\u4EFB\u52A1\u3002\u8BF7\u6838\u5BF9\u73B0\u573A\u540E\u786E\u8BA4\u4E0D\u786E\u5B9A\u6548\u679C";
      this.task.effectsUncertain = true;
      this.save("restart_interrupted");
    }
  }
  save(event, detail = {}) {
    if (!this.task) return;
    this.task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    this.journal.append({ event, taskId: this.task.id, task: this.task, ...detail });
    this.journal.write(this.task);
  }
  status() {
    this.init();
    return this.task ? JSON.parse(JSON.stringify(this.task)) : null;
  }
  async start(value) {
    if (this.closed) throw new Error("\u63D2\u4EF6\u5DF2\u505C\u6B62");
    if (this.starting || this.loop) throw new Error("\u5DF2\u6709\u4EFB\u52A1\u8FD0\u884C\u6216\u6B63\u5728\u505C\u6B62");
    this.init();
    if (this.task?.effectsUncertain) throw new Error("\u4E0A\u6B21\u4EFB\u52A1\u6548\u679C\u4E0D\u786E\u5B9A\uFF1B\u5148\u6838\u5BF9\u73B0\u573A\u5E76\u663E\u5F0F\u786E\u8BA4");
    const goal = validateGoal(value);
    this.cancelRequested = false;
    goal.allowedRegion.allowCollect = goal.allowCollect;
    goal.allowedRegion.allowPlace = goal.allowPlace;
    this.starting = true;
    const id = (0, import_node_crypto2.randomUUID)();
    try {
      await this.body.acquireTask(id, goal.allowedRegion);
      if (this.closed || this.cancelRequested) throw new Error("\u4EFB\u52A1\u542F\u52A8\u5DF2\u53D6\u6D88");
      this.task = { id, goal, state: "running", reason: "\u76EE\u6807\u5DF2\u63A5\u6536", startedAt: (/* @__PURE__ */ new Date()).toISOString(), updatedAt: (/* @__PURE__ */ new Date()).toISOString(), actions: 0, effectsUncertain: false, skillLearned: false };
      this.save("task_started");
      this.loop = this.run(this.task).catch((error) => {
        if (this.task) {
          this.task.state = "blocked";
          this.task.reason = `\u4EFB\u52A1\u8BB0\u5F55\u6216\u6E05\u7406\u5931\u8D25\uFF1A${String(error)}`;
          this.task.effectsUncertain = true;
        }
      }).finally(() => {
        this.loop = void 0;
      });
      return this.status();
    } catch (error) {
      if (this.task?.id === id) {
        this.task.state = "blocked";
        this.task.effectsUncertain = true;
        this.task.reason = String(error);
      }
      await this.body.releaseTask(id);
      throw error;
    } finally {
      this.starting = false;
    }
  }
  requestCancel() {
    const cancellingTask = this.task;
    const fail = (error) => {
      if (cancellingTask && this.task === cancellingTask) {
        cancellingTask.effectsUncertain = true;
        cancellingTask.reason = `\u53D6\u6D88\u8C03\u7528\u5931\u8D25\uFF1A${String(error)}`;
      }
    };
    try {
      const result = this.body.cancel();
      if (result && typeof result.catch === "function") void result.catch(fail);
    } catch (error) {
      fail(error);
    }
  }
  async cancel() {
    this.cancelRequested = true;
    if (!this.journal && !this.starting && !this.loop) return null;
    this.init();
    if (this.loop) {
      this.requestCancel();
      if (this.task) {
        this.task.reason = "\u53D6\u6D88\u5DF2\u8BF7\u6C42\uFF0C\u7B49\u5F85\u5E95\u5C42\u52A8\u4F5C\u7ED3\u675F\uFF1B\u4E0D\u4F1A\u542F\u52A8\u4E0B\u4E00\u6B65";
        this.save("cancel_requested");
      }
    }
    return this.status();
  }
  async acknowledgeEffects() {
    this.init();
    if (this.loop || this.starting) throw new Error("\u7B49\u5F85\u4EFB\u52A1\u53CA\u5E95\u5C42\u52A8\u4F5C\u7ED3\u675F\u540E\u518D\u786E\u8BA4");
    if (this.task?.effectsUncertain) {
      await this.body.assertQuiescent?.(this.task.goal.allowedRegion);
      this.task.effectsUncertain = false;
      this.task.reason = "\u7528\u6237\u5DF2\u786E\u8BA4\u73B0\u573A\uFF1B\u65E7\u4EFB\u52A1\u4ECD\u4E0D\u6062\u590D\uFF0C\u4E0B\u4E00\u6B21\u987B\u663E\u5F0F\u65B0\u5EFA";
      this.save("effects_acknowledged");
    }
    return this.status();
  }
  async run(task) {
    const deadline = Date.now() + task.goal.timeoutMs;
    let timer;
    try {
      timer = setTimeout(() => {
        this.cancelRequested = true;
        this.requestCancel();
      }, task.goal.timeoutMs);
      while (true) {
        if (this.cancelRequested || this.closed) {
          task.state = "cancelled";
          task.reason = Date.now() >= deadline ? "\u65F6\u95F4\u9884\u7B97\u5DF2\u5230" : "\u4EFB\u52A1\u5DF2\u505C\u6B62";
          break;
        }
        const observed = await this.body.observeTask(task.id, task.goal.allowedRegion);
        const before = sanitizeSnapshot(observed);
        task.lastSnapshot = before;
        if (this.cancelRequested || this.closed) continue;
        if (!before.connected) {
          task.state = "interrupted";
          task.reason = "\u8EAB\u4F53\u65AD\u5F00\uFF1B\u4E0D\u81EA\u52A8\u6062\u590D";
          break;
        }
        if (before.activeAction) {
          task.state = "blocked";
          task.reason = "\u8EAB\u4F53\u52A8\u4F5C\u69FD\u5C1A\u672A\u91CA\u653E\uFF08\u542B draining\uFF09";
          break;
        }
        let decision = planNext(observed, { ...task.goal, actionBudget: task.goal.actionBudget - task.actions });
        if (decision.kind === "completed" && task.goal.equip && before.heldItem !== "wooden_pickaxe") decision = { kind: "action", action: { action: "equip", material: "wooden_pickaxe" }, reason: "\u80CC\u5305\u76EE\u6807\u5DF2\u6EE1\u8DB3\uFF0C\u4ECD\u987B\u6838\u9A8C\u5B9E\u9645\u624B\u6301" };
        this.save("observed_plan", { before, decision });
        if (decision.kind !== "action") {
          task.state = decision.kind;
          task.reason = decision.reason;
          if (decision.kind === "completed") task.outcomeBasis = "observed_inventory_and_equipment";
          break;
        }
        if (task.actions >= task.goal.actionBudget || Date.now() >= deadline) {
          task.state = "blocked";
          task.reason = "\u4EFB\u52A1\u9884\u7B97\u8017\u5C3D";
          break;
        }
        if (this.cancelRequested || this.closed) continue;
        const action = { ...decision.action, timeoutMs: Math.max(1e3, Math.min(3e4, deadline - Date.now())) };
        task.actions++;
        this.save("action_intent", { before, action, actionSequence: task.actions });
        let result;
        try {
          result = await this.body.taskAction(task.id, action, task.goal.allowedRegion);
        } catch (error) {
          task.effectsUncertain = true;
          throw error;
        }
        result = { ...result, before: result.before ? sanitizeSnapshot(result.before) : void 0, after: result.after ? sanitizeSnapshot(result.after) : void 0 };
        task.lastAction = result;
        task.effectsUncertain = task.effectsUncertain || !!result.effectsUncertain;
        this.save("action_result", { actionId: result.id, before, result, after: result.after });
        if (task.effectsUncertain) {
          task.state = "blocked";
          task.reason = "\u52A8\u4F5C\u6548\u679C\u4E0D\u786E\u5B9A\uFF1B\u505C\u6B62\u81EA\u52A8\u6267\u884C\uFF0C\u9700\u6838\u5BF9\u73B0\u573A\u5E76\u786E\u8BA4";
          break;
        }
        if (this.cancelRequested || this.closed) continue;
        if (result.status !== "completed") {
          task.state = result.status === "disconnected" ? "interrupted" : "blocked";
          task.reason = `\u52A8\u4F5C\u672A\u5B8C\u6210\uFF1A${result.reason || result.status}`;
          break;
        }
      }
    } catch (error) {
      task.state = "blocked";
      task.reason = error instanceof Error ? error.message : String(error);
      if (task.lastAction?.effectsUncertain) task.effectsUncertain = true;
    } finally {
      clearTimeout(timer);
      try {
        await this.body.releaseTask(task.id);
      } catch (error) {
        task.effectsUncertain = true;
        task.state = "blocked";
        task.reason = `\u91CA\u653E\u8EAB\u4F53\u5931\u8D25\uFF1A${String(error)}`;
      }
      this.save("task_finished");
    }
  }
  async close() {
    this.closed = true;
    await this.cancel();
    await this.loop;
  }
};

// plugins/minecraft-body/src/index.ts
var createPlugin = (createManager = (runtime, data) => new BodyManager(runtime, data)) => ({
  register(ctx) {
    const manager = createManager(import_node_path3.default.join(__dirname, "runtime"), ctx.storage.rootDir());
    const controller = new TaskController(manager, ctx.storage.rootDir());
    ctx.onDispose(async () => {
      await controller.cancel();
      await manager.close();
      await controller.close();
    });
    const accepting = (action) => {
      ctx.signal.throwIfAborted();
      return action();
    };
    ctx.registerIpc("body-status", () => accepting(() => manager.status()));
    ctx.registerIpc("body-start", (config) => accepting(() => manager.start(config)));
    ctx.registerIpc("body-action", (request) => accepting(() => manager.action(request)));
    ctx.registerIpc("body-cancel", () => accepting(() => {
      void controller.cancel();
      return manager.cancel();
    }));
    ctx.registerIpc("body-stop", async () => {
      await controller.cancel();
      return manager.stop();
    });
    ctx.registerIpc("task-start", (goal) => accepting(() => controller.start(goal)));
    ctx.registerIpc("task-status", () => accepting(() => controller.status()));
    ctx.registerIpc("task-cancel", () => accepting(() => controller.cancel()));
    ctx.registerIpc("task-acknowledge-effects", () => accepting(() => controller.acknowledgeEffects()));
    const register = (tool) => ctx.registerTool({ ...tool, enabled: true, execute: async (args, context) => {
      ctx.signal.throwIfAborted();
      context?.signal?.throwIfAborted();
      return tool.execute(args, context);
    } });
    const point = { type: "object", properties: { x: { type: "number" }, y: { type: "number" }, z: { type: "number" } }, required: ["x", "y", "z"] };
    register({
      id: "minecraft-body_start_goal",
      name: "\u5F00\u59CB MC \u6728\u9550\u76EE\u6807",
      risk: "input-control",
      effectKind: "external_side_effect",
      verificationPolicy: "unknown",
      description: "\u4EC5\u5728\u5DF2\u624B\u52A8\u8FDE\u63A5\u7684 Minecraft \u8EAB\u4F53\u4E0A\u6267\u884C\u6728\u9550\u603B\u91CF1\u7684\u6709\u754C\u4EFB\u52A1\u3002\u4F1A\u6539\u53D8\u6E38\u620F\u4E16\u754C\uFF0C\u987B\u7ED9\u5B9A\u5141\u8BB8\u533A\u57DF\u548C\u91C7\u96C6/\u653E\u7F6E\u8BB8\u53EF\u3002\u5355\u52A8\u4F5C\u540E\u6838\u9A8C\u518D\u89C4\u5212\uFF0C\u65E0\u989D\u5916\u6A21\u578B\u8C03\u7528\u3002\u4E0D\u8FDE\u63A5\u670D\u52A1\u5668\uFF0C\u4E0D\u81EA\u52A8\u6062\u590D\u5931\u8D25\u4EFB\u52A1\u3002\u8FD4\u56DE\u4EFB\u52A1ID\uFF0C\u4F7F\u7528 status \u67E5\u770B\u5B9E\u9645\u7ED3\u679C\u3002",
      inputSchema: { type: "object", properties: { item: { type: "string", enum: ["wooden_pickaxe"] }, desiredTotal: { type: "integer", description: "\u4EC5\u5141\u8BB81" }, equip: { type: "boolean", description: "\u9ED8\u8BA4true\uFF0C\u5B8C\u6210\u5FC5\u987B\u771F\u5B9E\u624B\u6301\u6728\u9550" }, allowedRegion: { type: "object", properties: { dimension: { type: "string", enum: ["overworld"] }, min: point, max: point }, required: ["dimension", "min", "max"] }, allowCollect: { type: "boolean" }, allowPlace: { type: "boolean" }, timeoutMs: { type: "integer", description: "1000..300000\uFF0C\u9ED8\u8BA4120000" }, actionBudget: { type: "integer", description: "1..32\uFF0C\u9ED8\u8BA416" } }, required: ["item", "allowedRegion", "allowCollect", "allowPlace"] },
      async execute(args) {
        return JSON.stringify(await controller.start(args));
      }
    });
    register({ id: "minecraft-body_task_status", name: "\u67E5\u770B MC \u4EFB\u52A1\u72B6\u6001", risk: "safe", effectKind: "read", verificationPolicy: "none", description: "\u67E5\u770B\u4EFB\u52A1\u771F\u5B9E\u72B6\u6001\u3001\u6700\u540E\u89C2\u6D4B\u548C\u52A8\u4F5C\u7ED3\u679C\u3002completed\u53EA\u662F\u5F53\u524D\u7269\u54C1/\u88C5\u5907\u76EE\u6807\u6EE1\u8DB3\uFF0C\u4E0D\u4EE3\u8868\u5B66\u4F1A\u6280\u80FD\uFF1Bblocked\u4E0D\u81EA\u52A8\u91CD\u8BD5\u3002\u4E0D\u786E\u5B9A\u6548\u679C\u53EA\u80FD\u7531\u7528\u6237\u5728\u9762\u677FIPC\u660E\u786E\u786E\u8BA4\u540E\u89E3\u9664\u3002", inputSchema: { type: "object", properties: {}, required: [] }, async execute() {
      return JSON.stringify(controller.status());
    } });
    register({ id: "minecraft-body_cancel_task", name: "\u505C\u6B62 MC \u4EFB\u52A1", risk: "input-control", effectKind: "external_side_effect", verificationPolicy: "unknown", description: "\u505C\u6B62\u5F53\u524D\u76EE\u6807\uFF1B\u5E95\u5C42\u8C03\u7528\u53EF\u80FD\u4ECD\u5728draining\u3002\u4E0D\u4F1A\u64A4\u9500\u5DF2\u53D1\u751F\u4E16\u754C\u4FEE\u6539\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u6062\u590D\u3002", inputSchema: { type: "object", properties: {}, required: [] }, async execute() {
      return JSON.stringify(await controller.cancel());
    } });
  }
});
var index_default = createPlugin();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createPlugin
});
